# DESIGN.md — [CLIENT NAME]

Art direction + token rationale. Fill after kickoff / design gate. Keep in sync with `plan.md` locks (Section rhythm, Copy lock, Motion contract, Clone Blueprint).

**Multi-page only.**

---

## The business

| | |
|---|---|
| What it is | |
| Who visits | |
| The one action | |
| **The characteristic thing** | |
| Does NOT want to look like | |

---

## Direction: [name]

One paragraph: what this is, and why it belongs to this business.

| Axis | Position | Why |
|---|---|---|
| editorial ↔ corporate | | |
| warm ↔ cool | | |
| dense ↔ airy | | |
| geometric ↔ organic | | |
| understated ↔ bold | | |

---

## Principles

Decision rules — each must reject a future choice.

1.
2.
3.

---

## Signature element

**What:** (prefer peer move restyled)  
**Why it belongs:**  
**Where:** (once)

---

## Industry asset brief

| Job | Source | This project |
|---|---|---|
| Icons | Lucide | |
| Imagery | Unsplash / client | subjects: |
| PNG cutouts | Magnific / Pixabay / Pexels / client | yes/no — subjects (pre-cut only): |
| Graphics | Haikei | yes/no — why: |
| Illustrations | unDraw | yes/no — why: |
| UI patterns | Figma + shadcn | |
| Motion | `motion` | 2–3 moments: |

---

## Token rationale

| Group | Decision | Why |
|---|---|---|
| Color anchor | | |
| Neutral temperature | | |
| Display / body type | | license: |
| Type scale / tracking | | |
| Spacing / section rhythm | | must match plan Alternating / Uniform |
| Radius / elevation | | |
| Motion signature | | |

---

## Contrast

WCAG 4.5:1 body · 3:1 large/UI · APCA sanity check.

| Foreground | Background | WCAG | Pass | APCA Lc |
|---|---|---|---|---|
| on-surface | surface | | | |
| on-accent | accent | | | |
| accent | surface | | | |

---

## Layout plan

Mirror Clone Blueprint in `plan.md` (same order + archetypes).

| Section / block | Peer band | Archetype | Spacing token | Notes |
|---|---|---|---|---|
| | | | | |

- [ ] Band order matches blueprint · Do not invent respected
- [ ] Peer grammar logged in Decisions
- [ ] Hero `100vh` · header ≥ 40px · home ≥ 5 sections

---

## Motion plan

| Moment | What moves | Duration token | Easing token |
|---|---|---|---|
| | | | |

- [ ] Scroll reveals ≤ 2 · `prefers-reduced-motion` verified

---

## Decisions log

| Date | Considered | Rejected because |
|---|---|---|
| | | |

**Clone overrides** (peer grammar kept): e.g. pill CTAs, badges, wave dividers.
