# plan.md — [REQUIRED: CLIENT NAME] · Next.js + Sanity

| | |
|---|---|
| Template | **2.3** — client facts only (process lives in rules/skills) |
| Updated | 2026-09-17 |
| Document status | ⬜ Draft → ⬜ Confirmed → ⬜ In build → ⬜ Pre-ship → ⬜ Launched |

`[REQUIRED]` blocks the build. `(default)` = keep unless overridden. `⚠️ CONFIRM WITH CLIENT` = assumed.

Pipeline + locks: `AGENTS.md` · `.cursor/rules/` · `.cursor/skills/`. Soft-pass ban: `clone-fidelity.mdc`.

---

## Project Overview

| Field | Value |
|---|---|
| Client | [REQUIRED] |
| Industry / company type | [REQUIRED] |
| Primary goal (one action) | [REQUIRED] |
| Target audience | [REQUIRED] |
| Site language(s) | [REQUIRED] |
| One-line summary | [REQUIRED] |
| Characteristic thing this design should express | [REQUIRED] |
| Static / one-off pages (count) | [REQUIRED] |
| Collection types (count — 0 if none) | [REQUIRED] |

---

## Conversion

At least one channel **on**.

| Channel | On? | Detail |
|---|---|---|
| Phone | [REQUIRED: ✅/❌] | |
| Email | [REQUIRED: ✅/❌] | |
| SMS | [REQUIRED: ✅/❌] | |
| Booking URL | [REQUIRED: ✅/❌] | |
| Form | [REQUIRED: ✅/❌] | Destination below if ✅ |
| Store visit | [REQUIRED: ✅/❌] | |
| Other | [REQUIRED: ✅/❌] | |

| Field | Value |
|---|---|
| Primary CTA label | [REQUIRED — sentence case] |
| Form destination | [REQUIRED if Form ✅ — not Sanity — else N/A] |

---

## Sitemap & Routes

Home (`/`) ≥ 5 sections. Status: `live` · `hidden` · `deferred`.

| Page | Type | Route | Status | Sanity type | Visitor action |
|---|---|---|---|---|---|
| [REQUIRED: Home] | Static | `/` | [REQUIRED] | `page` | [REQUIRED] |
| [REQUIRED: add rows] | | | | | |
| 404 | code-only | — | live | — | Match direction |

---

## Collection index UX

Required only if collection count > 0. Else N/A.

| Field | Value |
|---|---|
| Index layout | [REQUIRED if collections] |
| Filters / sort | [REQUIRED if collections] |
| Empty state copy | [REQUIRED if collections] |
| Pagination / load more | [REQUIRED if collections] |
| Card → detail fields | [REQUIRED if collections] |

---

## Content Model

Confirm **before** schema code. Default: `page.sections[]` (~6–10 blocks) + `siteSettings`.

| Type | Purpose | Key fields |
|---|---|---|
| `page` | Flexible pages via `sections[]` | title, slug, seo, sections |
| [REQUIRED: collections if any] | | |
| `siteSettings` | Nav, footer, NAP, default SEO | navItems[], phone, email, address, social{}, defaultSeo |
| `seo` (object) | Per-doc SEO | metaTitle, metaDescription, ogImage |

**Page-builder blocks (launch):** [REQUIRED: ~6–10, mapped to sitemap]

---

## Design System

Stub at kickoff; expand via `design-system` into `DESIGN.md` + `@theme`. Logo = palette only — still run `industry-refs`.

### Direction

- Brand / logo on hand?: [REQUIRED]
- Style (3–5 adjectives): [REQUIRED or TBD after industry-refs]
- Client does not want to look like: [REQUIRED if given / —]

### Section rhythm

**Alternating** (default) = no identical consecutive padding · **Uniform** = identical padding allowed only when locked here.

**This project:** [REQUIRED: Alternating / Uniform]

### Tokens (after design-system; TBD OK at kickoff)

| Role | Value |
|---|---|
| Primary / accent | [REQUIRED or TBD] |
| Surface / text / border | [REQUIRED or TBD] |
| Display + body fonts | [REQUIRED or TBD — not Inter/Poppins/Roboto unless logged clone exception] |
| Radius / shadows | [REQUIRED or TBD] |

### Industry asset brief

Fill during `industry-refs` after clone pick. Sources: `from-industry.mdc`.

- Clone target: [REQUIRED after pick — name + URL]
- Peer grammar overrides: [REQUIRED after pick / none]
- Icons / imagery / PNG cutouts / Haikei / unDraw / components: [REQUIRED after pick]
- Motion: see **Motion contract**

### Clone Blueprint — Home

Empty until clone pick. Required fields: `clone-fidelity.mdc`. Empty after pick → stop.

| # | Band | Archetype | Element map | Type roles | CTA anatomy | Screenshots | Keep vs swap | Do not invent |
|---|---|---|---|---|---|---|---|---|
| 1 | [REQUIRED after pick] | | | | | | keep layout; swap colors/copy/photos/logo | |

### Clone Blueprint — Key pages

| Page | Band # | Band | Archetype | Element map | Type roles | CTA anatomy | Screenshots | Keep vs swap | Do not invent |
|---|---|---|---|---|---|---|---|---|---|
| [REQUIRED after pick] | 1 | | | | | | | keep layout; swap colors/copy/photos/logo | |

---

## Copy lock

| Key | Locked copy |
|---|---|
| `brand.name` | [REQUIRED] |
| `nav.primaryCta` | [REQUIRED — match Conversion] |
| `home.hero.headline` | [REQUIRED or TBD] |
| `home.hero.subline` | [REQUIRED or TBD] |
| `home.hero.cta` | [REQUIRED or TBD] |
| `footer.tagline` | [REQUIRED or TBD / —] |
| `contact.form.submit` | [REQUIRED if form / N/A] |
| `404.title` | [REQUIRED or TBD] |

---

## Motion contract

Fix passes must not strip locked motions.

| Field | Value |
|---|---|
| Libraries | [REQUIRED: `motion` default] |
| Sitewide scroll reveal | [REQUIRED: yes / no] |
| Max scroll-reveal sections | ≤ 2 per page |
| Signature moments (2–3) | [REQUIRED or TBD] |
| `prefers-reduced-motion` | Always |

---

## Content Checklist

Status: Pending / Requested / Received / Entered / Approved

| Asset | Who | Status |
|---|---|---|
| Logo (SVG + PNG) | Client | Pending |
| NAP, hours, social | Client | Pending |
| Nav labels | Me / Client | Pending |
| Home + static copy | [REQUIRED] | Pending |
| Collection seed | [REQUIRED / N/A] | Pending |
| Photos | Client | Pending |
| Legal (Privacy) | Me | Pending |
| Image + font licenses | Client / Me | Pending |

---

## Features

Sticky header + mobile menu always on. Form / call / booking = **Conversion** (don’t duplicate here).

| Feature | On? | Notes |
|---|---|---|
| Multi-level nav | [REQUIRED: ✅/❌] | Only if sitemap needs it |
| Collection pagination | [REQUIRED: ✅/❌] | If ~12–20+ items |
| Smooth-scroll / anchors | [REQUIRED: ✅/❌] | |
| Scroll animations | [REQUIRED: ✅/❌] | Obey Motion contract |
| Search | ❌ default | |
| Draft preview / visual edit | ❌ default | |
| Cookie banner | Auto | Only if cookie tracking |

---

## Ops

| Field | Value |
|---|---|
| Domain | [REQUIRED] |
| GitHub repo | [REQUIRED] |
| Sanity project ID | [REQUIRED when created] |
| Form backend | [REQUIRED or N/A] |
| Image path | [REQUIRED after verify: CF loader / Sanity CDN] |
| Analytics | (default: Cloudflare Web Analytics) |

---

## Deferred integrations

| Integration | Status | Notes |
|---|---|---|
| CMS (Sanity) | [REQUIRED: live / deferred] | |
| Host (Cloudflare) | [REQUIRED: live / deferred] | |
| Site URL | [REQUIRED: live URL / deferred] | |

---

## Pre-ship gate

| Gate | Done? |
|---|---|
| Clone QA vs peer PNGs | ⬜ |
| Soft-pass ban respected | ⬜ |
| Copy lock matches UI | ⬜ |
| Motion contract intact | ⬜ |
| Conversion paths work | ⬜ |
| Forms: labels, errors, spam | ⬜ |
| 404 matches direction | ⬜ |
| Launch-critical content Approved | ⬜ |
| Lighthouse / waiver | ⬜ |
| Handoff package ready | ⬜ |

---

## Handoff package

| Include | Exclude |
|---|---|
| Repo access | Peer screenshots / research dumps |
| Sanity (client-owned) | Internal agent notes |
| Domain + DNS notes | Secret values in chat/git |
| Env **names** + where set | Unlicensed stock |
| Form destination + test steps | |
| Analytics (if any) · editor how-to | |

---

## Handover

| Asset | Owner | Dev access after? |
|---|---|---|
| Domain | [REQUIRED] | [REQUIRED] |
| Cloudflare | [REQUIRED] | [REQUIRED] |
| GitHub | [REQUIRED] | [REQUIRED] |
| Sanity | [REQUIRED] | [REQUIRED] |
| Form / analytics | [REQUIRED] | [REQUIRED] |

---

## Out of Scope

Unless you explicitly expand:

- Single-page-only · e-commerce · types beyond Content Model · languages beyond Overview
- Advanced editorial beyond Sanity defaults · migrating an existing site/CMS
- Search (unless Features) · pro copy/photo/logo · ongoing SEO/marketing after launch
- Dark mode · paid typefaces (unless you buy) · reading other local project folders without an explicit path
