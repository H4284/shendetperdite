# Lessons — clone fidelity

Process lessons for agents and humans. Copied into new projects with the kit.

## Core rule

**Matching the peer’s mood, palette, or fonts ≠ a clone pass.**

Same band order, archetypes, element map, CTA anatomy, signature devices. Only colors, copy, photos, logo swap.

Soft-pass ban + failure table: `clone-fidelity.mdc`.

## What went wrong (real project)

Locked peer + blueprint, then shipped a category *mood board* instead of peer layout:

| Shipped | Why it failed |
|---|---|
| Colors + script + blobs matched mood | Mood only — not band structure |
| Press strips → centered nav buttons | Wrong job and layout |
| Wave + portrait → solid product hero | Freestyle reinterpretation |
| Hero box/pack → lone cutout | Wrong product role |
| Extra “featured” home band | Not on peer home |
| Build without overlay vs peer band PNG | Blueprint ignored |

Rules said “100% clone.” Without hard stops (peer PNG open → element map → clone-diff → don’t show on fail), agents still vibe-shipped.

## PNG cutouts

Blueprint needs product cutouts on color planes → **download pre-cut transparent PNGs**. No agent background removal.

Sources and rules: `from-industry.mdc`.

## Self-check (any home band)

- [ ] Peer crop open · blueprint row + Do not invent read
- [ ] L/R/float/bg and product role match peer
- [ ] Build screenshot taken · clone-diff boxes checked
- [ ] Side-by-side with peer = same section, different brand? If no → fail and fix
