# Start a new website

Paste into a **new Cursor chat**. Kit stays read-only.

```text
Start a new multi-page client website from my website kit at `/Users/home2/Desktop/website-plan`.

That kit is READ-ONLY — never edit, move, rename, or delete anything inside it. Work only in a NEW project folder you create. Stack is fixed: multi-page Next.js + Sanity + Cloudflare — do not propose alternatives. Do not scaffold, create Sanity, or write UI until the kickoff plan is filled and I confirm it.

Ask me one question only first: “What should we name the new website folder?” Wait for my answer. Do not create anything before I reply.

After I name it, create `/Users/home2/Desktop/<FOLDER_NAME>/`. If that folder already exists, stop and ask me what to do — do not overwrite. Copy from the kit into that folder (kit stays untouched): `plan.md`, `DESIGN.md`, `AGENTS.md`, `LESSONS.md`, `.gitignore`, and the entire `.cursor/` directory (all rules + skills). Do not copy the kit’s git history, node_modules, .next, .env*, screenshots, build artifacts, or any other client folders.

Confirm the kit was not modified. Open the new project with:
cursor -n "/Users/home2/Desktop/<FOLDER_NAME>"
If `cursor` is not on PATH, use: "/Applications/Cursor.app/Contents/Resources/app/bin/cursor" -n "/Users/home2/Desktop/<FOLDER_NAME>"

Then tell me: “Folder is ready — continue kickoff in the new Cursor window.” In that window, read `plan.md` (v2.3), `AGENTS.md`, and `LESSONS.md`; follow `.cursor/` rules and skills. Build is band-by-band vs peer PNGs after clone pick — vibe-only / “close enough” is a fail. Stop for my confirmation before any scaffolding or code.

Begin now: ask me the folder name.
```
