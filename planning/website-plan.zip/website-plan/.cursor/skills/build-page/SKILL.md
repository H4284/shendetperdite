---
name: build-page
description: >-
  Builds one route or Clone Blueprint band at a time; restyles to tokens;
  screenshots at 375 and 1440; fails unless clone match vs peer PNG passes.
  Use when implementing a page, block, or collection after plan and design
  are confirmed.
---

# Build page

## When

One page, block, or collection template — after plan + design confirmed.

## Gate

1. `plan.md` confirmed; `DESIGN.md` + `@theme` exist.
2. Clone Blueprint row for this unit — else `industry-refs` Gate B.
3. Content model confirmed if new Sanity types needed.
4. **One unit** this pass. Read Motion contract + Copy lock + asset brief.

## Do not

- All routes in one pass
- Hardcoded visuals — tokens only
- Invent or “improve away” blueprint chrome
- Ship default registry look
- Agent bg-remove — use pre-cut PNGs (`from-industry.mdc`)
- Present a unit that fails clone diff
- Soft-pass language (`clone-fidelity.mdc`)
- Code without peer PNG open
- Strip Motion contract / Copy lock
- Drive-by edits outside the named unit

## Build order

1. Shell (layout, nav, footer)
2. Home — one blueprint band at a time
3. Highest-value static page (often Contact)
4. Remaining static / Key pages
5. Collections (honor Collection index UX if any)
6. Full-site `design-qa` → Pre-ship

## Steps (one unit)

1. Name the unit. Open peer PNGs (375 + 1440). Missing → stop.
2. Element map check + read **Do not invent**. Match product role.
3. Implement with tokens. shadcn OK (ask first). Section rhythm from plan. Decorations under content, `pointer-events-none`.
4. Copy lock strings; images from asset brief — not peer photos.
5. Quiet quality: responsive, focus, reduced-motion, land at top.
6. Screenshot 375 + 1440. **Clone diff** — fail → fix; **don’t show user**.

## Clone diff (required)

```markdown
## Clone match: [band or route]
- Peer / build PNG paths (375 + 1440): …
- Element map: … · Do not invent checked
- [ ] Media side + product role · type roles · bg/wave · CTA anatomy · floating devices
- [ ] No extra chrome · band job matches peer · only colors/copy/photos/logo differ
- [ ] Motion contract intact · pass = layout match (not vibe)
```

## Handoff

```markdown
## Build unit: [route or band]
- [ ] Tokens · hard locks · blueprint · clone diff passed
- [ ] Asset brief only · no peer branding · Motion + Copy lock OK
- [ ] Screenshots 375 + 1440 · ready for next unit
```

## User “like this”

Save + measure before code. After two vague “bigger/more” nudges → ask once for a concrete target.

## Done when

One unit clone-diff passed and shown · next unit or `design-qa`.
