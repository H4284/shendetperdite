---
name: industry-refs
description: >-
  Researches multi-page website design patterns for a company type; Playwright
  screenshots (375/1440 + per-section); top 5 for user to pick clone target;
  fills Clone Blueprint + asset brief. Activate Playwright before any design
  search. Use for industry references, peers, or category assets before
  design-system. Run even when logo exists.
---

# Industry references

## When

Before design direction — including when a logo exists (palette only).

## Gate

Playwright first — ask, wait (`mcp.mdc`). Hard locks: `design.mdc`. Clone: `clone-fidelity.mdc`.

## Do

Playwright → research → **top 5** → **wait for user choice** → screenshot pack → Clone Blueprint (Home + Key pages) + asset brief → propose direction → `design-system`.

## Do not

- Research before Playwright
- Choose the clone target
- Copy peer branding
- Skip blueprint, **Do not invent**, or asset brief
- Invent home bands the peer lacks
- Drop in theme-marketplace code
- Write UI/schema before blueprint confirmed

## Steps

1. Read `plan.md`, `from-industry.mdc`, `clone-fidelity.mdc`.
2. Ask for Playwright — stop if no.
3. Research live peer sites (prefer as clone targets). Galleries OK as supplements. Optional A1/Firecrawl — ask first.
4. **Gate A** — top 5, stop until user picks.
5. Screenshot pack: full page + each major home band at **375 + 1440** → `.cursor/industry-refs/screenshots/<category-slug>/`.
6. Fill Clone Blueprint — Home + Key pages in `plan.md` (all fields in `clone-fidelity.mdc`). **Do not invent** required per band.
7. Lock asset brief (`from-industry.mdc`). Note product roles (box/pack vs cutout vs portrait).
8. Propose one direction (our brand only). Soft-pass ban applies (`clone-fidelity.mdc`).
9. On agreement → write into `plan.md` → **`design-system`**.

## Gate A

```markdown
## Top 5 for [category]
1. [name] — [URL] — why: …
2. …
3. …
4. …
5. …

**Which should we copy?** Reply with a number (or mix, e.g. “1 for home, 4 for contact”).
```

## Gate B (after choice)

```markdown
## Chosen clone target
[name/URL] — layout 100% / brand swap only

## Screenshot pack
- Full page + per-section bands: [paths]

## Clone Blueprint — Home / Key pages
(tables in plan.md — every band has Do not invent + CTA anatomy)

## Peer grammar to keep
- …

## Direction + asset brief
- Sitemap / home bands (= blueprint) / primary CTA / our color+type / product roles
- Icons · imagery · PNG cutouts · Haikei · unDraw · components · motion
```

## Done when

User chose · screenshot pack done · blueprints + Do not invent in `plan.md` · asset brief locked · user OK for `design-system`.
