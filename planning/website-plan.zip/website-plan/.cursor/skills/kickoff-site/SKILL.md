---
name: kickoff-site
description: >-
  Runs the plan.md kickoff interview for a new multi-page Next.js + Sanity site,
  fills placeholders, proposes content model and design direction, and stops
  before scaffolding. Use when starting a new website, when plan.md still has
  [REQUIRED] fields, or when the user says kickoff, interview, or start project.
---

# Kickoff site

## When

- `plan.md` has `[REQUIRED: ...]`
- User asks to start / kick off
- Work in a **client folder** from `START-NEW-SITE.md` — not the source kit

## Gate

1. User wants a new client inside the kit → point to `START-NEW-SITE.md`; don’t fill the kit as the client.
2. Status ≥ Confirmed → gap-fill only unless user asks to revise.
3. Don’t read other local projects unless user pastes a path.
4. Multi-page only (`design.mdc`).

## Do not

- Scaffold, Sanity, or push until user **confirms** the plan
- Full visual system from logo — leave to `industry-refs` → `design-system`
- Paste process essays into `plan.md`
- Invent client-specific defaults
- Ask every question in one message — **one topic per turn**

## Fill in `plan.md`

Project Overview · Conversion · Sitemap · Collection index UX (if any) · Content Model · Design System stub · Copy lock · Motion contract · Content Checklist · Features · Ops · Deferred · Pre-ship · Handoff · Handover · Out of Scope.

Clone Blueprint tables stay empty until `industry-refs`.

## Steps

1. Read `plan.md`, `AGENTS.md`, `LESSONS.md`. Status ≥ Confirmed → gap-fill only.
2. **Round 1 — facts** (one topic per turn): name, industry, goal, Conversion channels + CTA, language(s), domain / owners.
3. **Round 2 — propose defaults:** brand assets?, multi-page sitemap with status, collection UX if needed, Section rhythm (Alternating default), Copy lock keys, Features toggles, Motion stubs, Ops/Deferred.
4. Fill every `[REQUIRED]`. Guesses → `⚠️ CONFIRM WITH CLIENT`. Unknown design → TBD after industry-refs.
5. Content model: types + ~6–10 page-builder blocks mapped to sitemap.
6. Design stub only (adjectives, characteristic thing, Section rhythm). Blueprint empty.
7. **Gate A** → wait for yes.

## Gate A

```markdown
## Kickoff summary
- Client / industry / goal: …
- Conversion + primary CTA: …
- Languages / sitemap (with status): …
- Collections / index UX: … or N/A
- Section rhythm / content model / Copy lock / Motion stubs: …
- Features / ops / handover: …
- Open ⚠️ / TBD: …

**Confirm this plan?** After yes → Confirmed → scaffold if needed → Playwright → `industry-refs`.
```

## After confirmation

Document status → Confirmed → scaffold if needed → ask Playwright once → `industry-refs` → `design-system` → `build-page` → `design-qa`.

## Done when

All `[REQUIRED]` filled or `⚠️`/TBD (except blueprints) · user confirmed · content model accepted.
