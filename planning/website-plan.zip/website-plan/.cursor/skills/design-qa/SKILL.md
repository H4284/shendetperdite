---
name: design-qa
description: >-
  Design QA on the running site — clone match vs peer screenshots first, then
  375/768/1440 screenshots, critique against DESIGN.md / Clone Blueprint /
  design.mdc, accessibility and performance. Use for design review or
  pre-launch review.
---

# Design QA

Full-site review near end of build — not a substitute for band-by-band `build-page`.

## Gate

1. Real client project with a running app — not the source kit / blank plan.
2. No blocking `[REQUIRED]`; `DESIGN.md` filled; blueprint present if clone target set.
3. Review URL (default `http://localhost:3000`) serves **this** project.

Report Blockers for failed gates. Don’t fix until user approves.

## Steps

1. Playwright if needed (`mcp.mdc`).
2. **Clone QA first (Blocker):** home + key pages at 1440 and 375 vs peer pack. Taste Never cannot override blueprint.
3. Screenshot key templates at **375 / 768 / 1440**.
4. Critique vs `DESIGN.md`, `design.mdc`, `site-chrome.mdc`. Triage: **Blocker / High / Medium / Nit**.
5. A11y (axe). Performance via Chrome DevTools if asked — Lighthouse / LCP / CLS / INP vs `design.mdc`.
6. Report. Fix by tier — **only after approval**.

## Clone QA

```markdown
## Clone QA
- [ ] Band order matches blueprint (Home + Key pages)
- [ ] Each band: media role, type, shapes, CTA, no extra chrome
- [ ] Peer grammar present · Do not invent not violated
- [ ] No soft-pass language · Motion + Copy lock intact
- [ ] Only colors / copy / photos / logo differ
```

## Pass bar

Zero Blockers, zero High, axe clean on checked templates, perf targets met (or waiver). Soft-pass phrases = Blocker. Then tick Pre-ship in `plan.md`.
