---
name: design-system
description: >-
  Generates OKLCH palette, typography, Tailwind v4 @theme tokens, and DESIGN.md.
  Locks layout to Clone Blueprint. Use when filling design direction, creating
  tokens, choosing type, or before first components.
---

# Design system

## When

After kickoff + clone target — **before** first UI. Also when revising direction.

## Gate

1. Design `[REQUIRED]` clear (or user revising design only).
2. User chose clone target; Clone Blueprint Home + Key pages filled (`clone-fidelity.mdc`).
3. Read Section rhythm, Motion contract, Copy lock from `plan.md`.
4. Encode hard locks in `@theme` (`design.mdc`).

## Do not

- Whole system from logo alone
- Inter / Poppins / Roboto unless logged clone exception
- Components before `@theme` + filled `DESIGN.md`
- Reorder/replace blueprint bands
- Strip peer grammar for taste Never — log overrides in Decisions
- Soft-pass language (`clone-fidelity.mdc`)

## Steps

1. Read `plan.md`, `DESIGN.md`, `LESSONS.md`, `design.mdc`, `clone-fidelity.mdc`, `from-industry.mdc`.
2. One direction: **layout = blueprint**; **our** colors/type; **peer** shape/CTA grammar. Signature = peer move restyled.
3. OKLCH ramp (`culori`); contrast (`apca-w3` — body 4.5:1, large/UI 3:1).
4. Max 2 typefaces matching peer type roles. Note license.
5. Lock asset brief + Motion contract moments (≤2 scroll reveals).
6. Write `@theme` (color, type, space, radius, shadow, motion, `--hero-min-height`, `--header-height`). Honor Section rhythm.
7. Fill `DESIGN.md` + mirror into `plan.md`. Log peer grammar in Decisions.
8. **Gate B** — approval before `build-page`.

## Gate B

```markdown
## Design system for approval
- Direction + why / clone target
- Blueprint mirrored (Home + Key pages): yes — band count
- Section rhythm / peer grammar overrides / signature
- Palette anchors (semantic) / type + license / asset brief / motion
- Contrast OK / `@theme` has hero + header tokens

**Approve before build-page?**
```

## Done when

Layout plan = blueprint · Decisions log peer grammar · `@theme` exists · contrast passes · user approved → `build-page`.
