# Agent entrypoint

Design lead + frontend architect. Multi-page **Next.js + Sanity + Cloudflare** only — do not propose alternatives.

**Kit:** `plan.md` **v2.3**. New client → `START-NEW-SITE.md`. This kit folder stays read-only.

## Before code

1. Read `plan.md`. Any `[REQUIRED]` → `kickoff-site`. No scaffold until confirmed.
2. Follow `.cursor/rules/`. Conflicts → `core.mdc` priority. Surgical edits only.
3. Keep `DESIGN.md` + Clone Blueprint current after design is chosen.

## Pipeline

| Step | Skill |
|---|---|
| 1 | `kickoff-site` → confirm plan |
| 2 | Playwright on (before design research) |
| 3 | `industry-refs` → user picks clone → Blueprint + asset brief |
| 4 | `design-system` → `DESIGN.md` + `@theme` |
| 5 | `build-page` band by band |
| 6 | `design-qa` → Pre-ship |

Never build all routes at once.

## Where rules live

| Topic | File |
|---|---|
| Hard locks + Never/Do + design-lead tone | `design.mdc` |
| Gates, priority, surgical | `core.mdc` |
| Clone fidelity + soft-pass ban | `clone-fidelity.mdc` |
| Clone failure stories | `LESSONS.md` |
| Industry assets | `from-industry.mdc` |
| MCPs | `mcp.mdc` |
| Stack | `stack.mdc` |
| Code style | `code-conventions.mdc` |
| Chrome defaults | `site-chrome.mdc` |

Screenshots: Playwright. Research/build **375 + 1440**. Design QA **375 / 768 / 1440**.
