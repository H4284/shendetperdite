# Website kit — Next.js + Sanity multi-page sites

**Multi-page only.** Template: `plan.md` **2.3**.

This folder is the **source kit** — keep it read-only. Build only in a **new client folder** copied from here.

## Start a new site

1. New Cursor chat (not treating this kit as the working project).
2. Paste the prompt in [`START-NEW-SITE.md`](./START-NEW-SITE.md).
3. Agent asks for folder name → creates `/Users/home2/Desktop/<FOLDER_NAME>/` → copies kit files → opens that folder.
4. Continue kickoff there. No scaffold until `plan.md` is confirmed.

## What’s in a client folder

```
<FOLDER_NAME>/
├── plan.md          # what to build
├── DESIGN.md        # how it should look
├── AGENTS.md        # agent entry + pipeline
├── LESSONS.md       # clone-fidelity failures
├── .gitignore
└── .cursor/         # rules + skills
```

`README.md` and `START-NEW-SITE.md` stay in the kit only.

## Pipeline

`kickoff-site` → Playwright → `industry-refs` → `design-system` → `build-page` → `design-qa` → Pre-ship.

Stack: Next.js + Sanity + Cloudflare. Clone layout is hard — see `clone-fidelity.mdc`.

## File map

| File / folder | Role |
|---|---|
| `plan.md` | Client brief + Clone Blueprint + Pre-ship |
| `DESIGN.md` | Art direction + tokens rationale |
| `AGENTS.md` | Pipeline + which rule owns what |
| `LESSONS.md` | Real clone failures + self-check |
| `.cursor/rules/` | Always-on guardrails |
| `.cursor/skills/` | Step playbooks (kickoff → QA) |

Improve rules/skills **here first**, then copy into active client projects.
